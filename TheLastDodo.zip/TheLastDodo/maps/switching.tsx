<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="switching" tilewidth="64" tileheight="64" tilecount="6" columns="3">
 <image source="../../../../../../../../../pictures/Assets/GameParade2022/real/Map Tiles_Switch.png" width="192" height="128"/>
</tileset>
